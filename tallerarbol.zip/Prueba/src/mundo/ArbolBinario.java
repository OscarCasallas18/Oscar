package mundo;

public class ArbolBinario {
    Nodo raiz;

    ArbolBinario() {
        raiz = null;
    }

    void insertar(int valor) {
        raiz = insertarNodo(raiz, valor);
    }

    Nodo insertarNodo(Nodo raiz, int valor) {
        if (raiz == null) {
            raiz = new Nodo(valor);
            return raiz;
        }

        if (valor < raiz.valor)
            raiz.izquierda = insertarNodo(raiz.izquierda, valor);
        else if (valor > raiz.valor)
            raiz.derecha = insertarNodo(raiz.derecha, valor);

        return raiz;
    }

    void inOrden(Nodo nodo) {
        if (nodo != null) {
            inOrden(nodo.izquierda);
            System.out.print(nodo.valor + " ");
            inOrden(nodo.derecha);
        }
    }
}