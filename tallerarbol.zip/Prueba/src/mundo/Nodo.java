package mundo;

public class Nodo {
    int valor;
    Nodo izquierda, derecha;

    public Nodo(int item) {
        valor = item;
        izquierda = derecha = null;
    }

	@Override
	public String toString() {
		return "Nodo [valor=" + valor + ", izquierda=" + izquierda + ", derecha=" + derecha + "]";
	}
    
    
}