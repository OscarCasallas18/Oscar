package mundo;

public class App {

	public static void main(String[] args) {
        int[] arreglo = {15, 7, 18, 3, 12, 16, 19, 2, 4, 11, 0, 16, 17, 31, 22};
        ArbolBinario arbol = new ArbolBinario();

        for (int valor : arreglo) {
            arbol.insertar(valor);
        }

        System.out.println("Árbol binario de búsqueda creado con éxito:");
        //arbol.inOrden(arbol.raiz);
        System.out.println(arbol.raiz.toString());
        
        
    }
}
